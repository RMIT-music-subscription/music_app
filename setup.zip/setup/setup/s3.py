import json
import urllib.request
from setup.aws_cred import AWS

def download_from_github(github_url):
    response = urllib.request.urlopen(github_url)
    if response.status != 200:
        raise Exception(f"Failed to download {github_url}, Status Code: {response.status}")

    return response

def upload_S3_img(s3_client, file_key, data, contentType='image/jpg'):
    #Upload image to S3 bucket 
    s3_client.upload_fileobj(data, AWS.AWS_S3, file_key, ExtraArgs={"ContentType": contentType})


def setup_S3():
    # Download the img from github and then upload into the S3 bucket 
    s3 = AWS.aws_connect('s3')

    # Creating S3 bucket
    print("Creating the bucket", AWS.AWS_S3)
    s3.create_bucket(Bucket=AWS.AWS_S3)

    # Read the JSON file
    with open("setup/2025a1.json") as f:
        music_list = json.load(f)

        for song in music_list["songs"]:
            if song["img_url"]:
                raw_data = download_from_github(song["img_url"])
                upload_S3_img(s3, f"{song['artist'].replace(' ', '').lower()}.jpg", raw_data)

                print(f"{song['artist']} image has been successfully uploaded.")
            else:
                print(f"{song['artist'].replace(' ', '')} is not having image.")

        print(f"Images are uploaded in {AWS.AWS_S3} bucket")

    print("="*45)
    print("*"*3, " "*2, "S3 Bucket is ready to use", " "*2, "*"*3)
    print("="*45)

# def download_image_from_s3(s3_client, file_key, download_path):
#     try:
#         s3_client.download_file(AWS.AWS_S3, f'{file_key}.jpg', f'{download_path}.jpg')
#         print(f"Image downloaded successfully: {download_path}")
#     except Exception as e:
#         print(f"Error downloading {file_key} from S3: {e}")

#         response = boto3.client('s3', region_name='us-east-1').get_object(Bucket=AWS_S3, Key=image_key)

#         image_data = response['Body'].read()

#         # Convert the image data to base64
#         base64_image = base64.b64encode(image_data).decode('utf-8')
#         return base64_image