import boto3

class AWS:
    ACCESS_KEY = "ASIATST2KKRLDKOZWRAV"
    SECRET_KEY = "UAKdaZQgCGIibjQfSVANvfb5Gfm/CT7Xo0ycxH+1"
    SESSION_TOKEN = "IQoJb3JpZ2luX2VjECMaCXVzLXdlc3QtMiJHMEUCIA+Dylboz2bshfDNfZ1sKk7yRmtQ5AypS27Egww5Ktf9AiEAtWjBKlVAR0YqXz9j6yve6bTNltdaRG5s73s5EPzRgVYqvwIInP//////////ARABGgwyNDYxNDM0MDcxOTAiDHy75vt9tpz5O8JLMSqTAmrwbnAaKyYfE+sXTSc/PlvsV/MCNmMOnnGQubY7jIxtzpzP/m+6f74HEAZMZxIZMUy08Wgc3mWEy2HOYRltazhYDbtH29rtdTx6JULNHvm/o/j9Vg112YRpS1BRG1VqoTOZgqxfVo922UlKzxbud0+9SRILs3YjjsnPy4mUwij8OX+khYBk0A9Kqm4Fxka1YIl87TS/GBlzJLx/ryPjkyZ85BAM57Hvq414g+uNRPmCsWh8lWTi3s30OV3PoooTQcWyRqRUzYH3aYXiudwBz7HUwtg9GnhN+X3Tnf/b2UkWAXzlxReJB3FsRspZ8i123wBgrs3diJbbPubQqpNGZ686sBcM9EIRiay77SgRDJBUi60oMP3j3L8GOp0BI7A06z2vdF3oMnNJk/gcTbqJcMINHar80sawwXrpk6isB8/QRV0Q3jLC6Nu6de6Wlz9g40I3IYOmD9najidhsGDKuRr8RdY52a7FYUjl34IUBh8pyE32cIa3OZ6GN42SHIjY35q3K4XktazN91pgok9hWgWhXJQisePtv1tYfUI9XFKS7F6LYcMqqxLpv+lMfZY3DHyLzLZ9OZTJUg=="
    REGION = "us-east-1"
    AWS_S3 = "music-rmit-asv33"
    LOGIN_TABLE = "login"
    MUSIC_TABLE = "music"
    SUBSCRIBE_TABLE = "subscribe"

    def aws_connect(service = 'dynamodb'):
        s3_client = boto3.client(
                service,
                aws_access_key_id = AWS.ACCESS_KEY,
                aws_secret_access_key = AWS.SECRET_KEY,
                aws_session_token = AWS.SESSION_TOKEN,
                region_name = AWS.REGION
            )
        return s3_client