from setup.aws_cred import AWS

def setup_subscribe_table():
    dynamodb = AWS.aws_connect()

    dynamodb.create_table(
        TableName=AWS.SUBSCRIBE_TABLE,
        KeySchema=[
            {'AttributeName': 'subscribe_id', 'KeyType': 'HASH'}  # Primary key: subscribe_id
        ],
        AttributeDefinitions=[
            {'AttributeName': 'subscribe_id', 'AttributeType': 'S'},      
            {'AttributeName': 'user_email', 'AttributeType': 'S'}    
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 5,
            'WriteCapacityUnits': 5
        },
        GlobalSecondaryIndexes=[
            {
                'IndexName': 'UserEmailIndex',
                'KeySchema': [
                    {'AttributeName': 'user_email', 'KeyType': 'HASH'}  # GSI Partition key
                ],
                'Projection': {
                    'ProjectionType': 'ALL'
                },
                'ProvisionedThroughput': {
                    'ReadCapacityUnits': 5,
                    'WriteCapacityUnits': 5
                }
            }
        ]
    )

    print("="*50)
    print("*"*3, " "*2, "Subscribe table is ready to use", " "*2, "*"*3)
    print("="*50)