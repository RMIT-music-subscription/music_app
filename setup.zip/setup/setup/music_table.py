import json
import time
import uuid
from setup.aws_cred import AWS

# Function to create music table
def create_music_table(dynamodb):
    try:
        existing_tables = dynamodb.list_tables()["TableNames"]
        if AWS.MUSIC_TABLE in existing_tables:
            print(f"Table '{AWS.MUSIC_TABLE}' already exists.")
            return
        # dynamodb.create_table(
        #         TableName=AWS.MUSIC_TABLE,
        #         KeySchema=[
        #             {'AttributeName': 'music_id', 'KeyType': 'HASH'}  # Primary key: music_id
        #         ],
        #         AttributeDefinitions=[
        #             {'AttributeName': 'music_id', 'AttributeType': 'S'},
        #             {'AttributeName': 'artist', 'AttributeType': 'S'},
        #             {'AttributeName': 'title', 'AttributeType': 'S'},
        #             {'AttributeName': 'album', 'AttributeType': 'S'},
        #             {'AttributeName': 'year', 'AttributeType': 'N'} 
        #         ],
        #         ProvisionedThroughput={
        #             'ReadCapacityUnits': 10,
        #             'WriteCapacityUnits': 10
        #         },
        #         GlobalSecondaryIndexes=[
        #             {
        #                 'IndexName': 'ArtistTitleIndex',
        #                 'KeySchema': [
        #                     {'AttributeName': 'title', 'KeyType': 'HASH'},
        #                     {'AttributeName': 'artist', 'KeyType': 'RANGE'}
        #                 ],
        #                 'Projection': {
        #                     'ProjectionType': 'ALL'
        #                 },
        #                 'ProvisionedThroughput': {
        #                     'ReadCapacityUnits': 10,
        #                     'WriteCapacityUnits': 10
        #                 }
        #             },
        #             {
        #                 'IndexName': 'ArtistIndex',
        #                 'KeySchema': [
        #                     {'AttributeName': 'artist', 'KeyType': 'HASH'}
        #                 ],
        #                 'Projection': {
        #                     'ProjectionType': 'ALL'
        #                 },
        #                 'ProvisionedThroughput': {
        #                     'ReadCapacityUnits': 10,
        #                     'WriteCapacityUnits': 10}
        #             },
        #             {
        #                 'IndexName': 'AlbumIndex',
        #                 'KeySchema': [
        #                     {'AttributeName': 'album', 'KeyType': 'HASH'}
        #                 ],
        #                 'Projection': {
        #                     'ProjectionType': 'ALL'
        #                 },
        #                 'ProvisionedThroughput': {
        #                     'ReadCapacityUnits': 10,
        #                     'WriteCapacityUnits': 10}
        #             },
        #             {
        #                 'IndexName': 'YearIndex',
        #                 'KeySchema': [
        #                     {'AttributeName': 'year', 'KeyType': 'HASH'}
        #                 ],
        #                 'Projection': {
        #                     'ProjectionType': 'ALL'
        #                 },
        #                 'ProvisionedThroughput': {
        #                     'ReadCapacityUnits': 10,
        #                     'WriteCapacityUnits': 10}
        #             },
        #             {
        #                 'IndexName': 'TitleIndex',
        #                 'KeySchema': [
        #                     {'AttributeName': 'title', 'KeyType': 'HASH'}
        #                 ],
        #                 'Projection': {
        #                     'ProjectionType': 'ALL'
        #                 },
        #                 'ProvisionedThroughput': {
        #                     'ReadCapacityUnits': 10,
        #                     'WriteCapacityUnits': 10}
        #             }
        #         ]
        #     )

        dynamodb.create_table(
                TableName="music",
                AttributeDefinitions=[
                    {"AttributeName": "music_id", "AttributeType": "S"}
                ],
                KeySchema=[
                    {"AttributeName": "music_id", "KeyType": "HASH"}
                ],
                ProvisionedThroughput={"ReadCapacityUnits": 5, "WriteCapacityUnits": 5}
            )

        print("Creating table 'music'...")
        

    except Exception as e:
        print(f"Error creating table: {str(e)}")

# Function to wait until the table is active
def is_table_active(dynamodb, table_name):
    while True:
        try:
            table_status = dynamodb.describe_table(TableName=table_name)['Table']['TableStatus']
            if table_status == "ACTIVE":
                print(f"Table {table_name} is now ACTIVE.")
                break
        except dynamodb.exceptions.ResourceNotFoundException:
            pass

        time.sleep(5)

def insert_user(dynamodb):
    # Load JSON data into the table
    with open("setup/2025a1.json") as f:
            music_list = json.load(f)

            for song in music_list["songs"]:
                music_id = str(uuid.uuid4())

                dynamodb.put_item(
                    TableName=AWS.MUSIC_TABLE,
                    Item={
                        'music_id': {'S': music_id},  
                        'artist': {'S': song['artist']},
                        'title': {'S': song['title']},
                        'year': {'N': song['year']},
                        'album': {'S': song['album']},
                        'img_url': {'S': f"{song['artist'].replace(' ','').lower()}.jpg"}
                        }
                    )
                
                print(f"{music_id} is inserted successfully")

def setup_music_table():
    dynamodb = AWS.aws_connect("dynamodb")
    create_music_table(dynamodb)
    is_table_active(dynamodb, AWS.MUSIC_TABLE)
    insert_user(dynamodb)

    print("="*45)
    print("*"*3, " "*2, "Music table is ready to use", " "*2, "*"*3)
    print("="*45)