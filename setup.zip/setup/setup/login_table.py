import time
from setup.aws_cred import AWS

def create_login_table(dynamodb):
    # Creates the 'login' table in DynamoDB if it does not exist.

    try:
        existing_tables = dynamodb.list_tables()["TableNames"]
        if AWS.LOGIN_TABLE in existing_tables:
            print(f"Table '{AWS.LOGIN_TABLE}' already exists.")
            return
        
        # Table creation code is refered from AWS documentation and chatGPT
        response = dynamodb.create_table(
                TableName = AWS.LOGIN_TABLE,
                KeySchema=[
                    {'AttributeName': 'email', 'KeyType': 'HASH'}
                ],
                AttributeDefinitions=[
                    {'AttributeName': 'email', 'AttributeType': 'S'},
                    {'AttributeName': 'user_name', 'AttributeType': 'S'}
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 5,
                    'WriteCapacityUnits': 5
                },
                GlobalSecondaryIndexes=[
                    {
                        'IndexName': 'UserNameIndex',
                        'KeySchema': [
                            {'AttributeName': 'user_name', 'KeyType': 'HASH'}
                        ],
                        'Projection': {
                            'ProjectionType': 'ALL'
                        },
                        'ProvisionedThroughput': {
                            'ReadCapacityUnits': 2,
                            'WriteCapacityUnits': 2
                        }
                    }
                ]
            )

        print("Table creation initiated:", response)
        print(f"Table '{AWS.LOGIN_TABLE}' created successfully.")

    except Exception as e:
        print(f"Error creating table: {str(e)}")

# Function to wait until the table is active
def is_table_active(dynamodb, table_name):
    while True:
        try:
            table_status = dynamodb.describe_table(TableName=table_name)['Table']['TableStatus']
            if table_status == "ACTIVE":
                print(f"Table {table_name} is now ACTIVE.")
                break
        except dynamodb.exceptions.ResourceNotFoundException:
            pass

        time.sleep(5)

def insert_user(dynamodb):

    # Create default user
    print("Creating 10 users in Table")
    for idx in range(0,9):
        # Save user details to DynamoDB
        dynamodb.put_item(
            TableName="login",
            Item={
                "email": {"S": f"s4068455{idx}@student.rmit.edu.au"},
                "user_name": {"S": f"AswinKumar{idx}"},
                "password": {"S": f"123456{idx}"}
                }
            )
    print("Succefully created 10 users in Table")

def setup_login_table():
    dynamodb = AWS.aws_connect("dynamodb")
    create_login_table(dynamodb)
    is_table_active(dynamodb, AWS.LOGIN_TABLE)
    insert_user(dynamodb)

    print("="*45)
    print("*"*3, " "*2, "Login table is ready to use", " "*2, "*"*3)
    print("="*45)