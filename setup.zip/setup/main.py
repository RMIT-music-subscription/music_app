from setup.s3 import setup_S3
from setup.login_table import setup_login_table
from setup.music_table import setup_music_table
from setup.subscribe_table import setup_subscribe_table


if __name__ == "__main__":
    #setup_S3()
    #setup_login_table()
    setup_music_table()
    #setup_subscribe_table()