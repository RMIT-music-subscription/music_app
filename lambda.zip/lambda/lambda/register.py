import json
import re
import boto3

dynamodb = boto3.client('dynamodb', region_name='us-east-1')

def validate_payload(data):
    # Extract fields
    password = data.get("password")
    username = data.get("user_name")
    email = data.get("email")

    # Email validation
    email_regex = r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)"
    if not email or not re.match(email_regex, email):
        raise Exception("Invalid email address", 400)

    # Username validation
    if not username or len(username) < 3:
        raise Exception("Username should be at least 3 characters long", 400)

    # Password validation
    if not password or len(password) < 8:
        raise Exception("Password must be at least 8 characters long", 400)

    return (email, username, password)

def is_user_exist(email):
    # Check if email already exists in DynamoDB
    existing_user = dynamodb.get_item(
        TableName="login",
        Key={"email": {"S": email}}
    )

    if "Item" in existing_user:
        raise Exception("Email address already exists", 400)

def add_user(cred):
    email, username, password = cred

    # Save user details to DynamoDB
    dynamodb.put_item(
        TableName="login",
        Item={
            "email": {"S": email},
            "user_name": {"S": username},
            "password": {"S": password}
        }
    )

def lambda_handler(event, context):
    try:
        body = event
        print("Event:", context)
        cred = validate_payload(body)
        is_user_exist(body.get("email"))
        add_user(cred)

        return {"statusCode": 201, "body": {"message": "User registered successfully"}}

    except Exception as e:
        return {
            "statusCode": e.args[1] if len(e.args) > 1 else 500, 
            "body": {"error": str(e.args[0] if len(e.args) > 0 else "Internal Error")}
        }
