import json
import  base64
import boto3

from auth_utils import verify_token

dynamodb = boto3.client('dynamodb', region_name='us-east-1')
s3_client = boto3.client('s3', region_name='us-east-1')

def music_response(data):
    music_list = []
    img_key = set()

    for music in data:
        img_key.add(music["img_url"]["S"])
        response = {
            "music_id": music["music_id"]["S"],
            "artist" : music["artist"]["S"],
            "title": music["title"]["S"],
            'year': music["year"]["N"],
            "album": music["album"]["S"],
            "img": music["img_url"]["S"]
        }

        music_list.append(response)

    return music_list, img_key

def fetch_music(email):
    response = dynamodb.scan(
        TableName="subscribe",
        FilterExpression="user_email = :email",
        ExpressionAttributeValues={":email": {"S": email}}
    )
    print("respone list",response)
    if response.get("Count") == 0:
        return []
    
    subscription_data = response.get("Items") 
    music_ids = [item["music_id"]["S"] for item in subscription_data]

    keys = [{"music_id": {"S": music_id}} for music_id in music_ids]

    response = dynamodb.batch_get_item(
        RequestItems={
            "music": {  # Ensure the table name is correct
                "Keys": keys
            }
        }
    )
    print("Music response", response)
    # Extract items from the response
    return response.get("Responses", {}).get("music", [])

def get_img(img_set):
    img = {}
    for image_key in img_set:
        response = s3_client.get_object(Bucket="music-rmit-asv", Key=image_key)

        image_data = response['Body'].read()

        # Convert the image data to base64
        base64_image = base64.b64encode(image_data).decode('utf-8')
        img[image_key] = base64_image
    
    return img

def lambda_handler(event, context):
    print("Event::",event)

    try:
        token = event.get("token") 
        if not token:
            return {
                "statusCode": 401,
                "body": json.dumps({"error": "Token not provided"})
            }
        
        result = verify_token(token)
        
        print("Token", result)
        if not result["valid"]:
            return {
                "statusCode": 401,
                "body": {"error": result["error"]}
            }

        music_details = fetch_music(result["user"]["email"])
        print("Music details", music_details)
        if len(music_details) == 0:
            return {"statusCode":201, "body" : {"error":"No music subscribed"}}

        music, img_set = music_response(music_details)
        img_base64 = get_img(img_set)

        print("End of response", music,img_base64)
        return {"statusCode":201, "body" : {"music":music, "img_base64": img_base64}}

    except Exception as e:
        print(e)
        return {
            "statusCode": e.args[1] if len(e.args) > 1 else 500, 
            "body": {"error": str(e.args[0] if len(e.args) > 0 else 'Internal error. Try again')}
        }