import base64
import datetime
import json
import boto3
from boto3.dynamodb.conditions import Attr
from decimal import Decimal
from auth_utils import verify_token
 
SUBSCRIBE_TABLE = "subscribe"
MUSIC_TABLE = "music"
AWS_S3 = "music-rmit-asv"
 
s3_client = boto3.client('s3', region_name='us-east-1')
dynamodb = boto3.resource("dynamodb", region_name='us-east-1')
table = dynamodb.Table(MUSIC_TABLE)
 
def filter_music(artist=None, album=None, title=None, year=None):
    filter_expr = None
 
    if artist:
        filter_expr = Attr("artist").eq(artist)
    if album:
        filter_expr = filter_expr & Attr("album").eq(album) if filter_expr else Attr("album").eq(album)
    if title:
        filter_expr = filter_expr & Attr("title").eq(title) if filter_expr else Attr("title").eq(title)
    if year:
        filter_expr = filter_expr & Attr("year").eq(year) if filter_expr else Attr("year").eq(Decimal(year))
 
    # If no filters provided, return all
    if filter_expr:
        response = table.scan(FilterExpression=filter_expr)
    else:
        raise Exception("Please enter details to search", 400)
 
 
    return response.get("Items", [])
 
def music_response(data):
    music_list = []
    img_key = set()
 
    for music in data:
        img_key.add(music["img_url"]["S"])
        response = {
            "music_id": music["music_id"]["S"],
            "artist" : music["artist"]["S"],
            "title": music["title"]["S"],
            'year': music["year"]["N"],
            "album": music["album"]["S"],
            "img": music["img_url"]["S"]
        }
 
        music_list.append(response)
 
    return music_list, img_key
 
 
def get_img(img_set):
    print("img_set", img_set)
    img = {}
    for image_key in img_set:
        response = s3_client.get_object(Bucket="music-rmit-asv", Key=image_key)
 
        image_data = response['Body'].read()
 
        # Convert the image data to base64
        base64_image = base64.b64encode(image_data).decode('utf-8')
        img[image_key] = base64_image
    
    return img
  
def lambda_handler(event, context):
    print(event)
 
    try:
        token = event.get("token")
        if not token:
            return {
                "statusCode": 401,
                "body": json.dumps({"error": "Token not provided"})
            }
        
        result = verify_token(token)
        
        print("Token", result)
        if not result["valid"]:
            return {
                "statusCode": 401,
                "body": {"error": result["error"]}
            }
        
        music_details = filter_music(event.get("artist"),event.get("album"), event.get("title"),event.get("year"))
        print("music_details",music_details)
 
        if len(music_details) ==0:
            return {"statusCode": 404, "body": {"error": "No music found"}}
            
        img_base64 = get_img(set([music["img_url"]for music in music_details]))
 
        print("End of response", music_details,img_base64)
        return {"statusCode":201, "body" : {"music":music_details, "img_base64": img_base64}}
 
    except Exception as e:
        print(e)
        return {
            "statusCode": e.args[1] if len(e.args) > 1 else 500,
            "body": {"error": e.args[0] if len(e.args) > 0 else 'Internal error. Try again'}
        }
 