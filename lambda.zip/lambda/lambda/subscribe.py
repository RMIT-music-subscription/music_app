import json
import boto3
from auth_utils import verify_token

SUBSCRIBE_TABLE = "subscribe"
MUSIC_TABLE = "music"
AWS_S3 = "music-rmit-asv"
dynamodb = boto3.client('dynamodb', region_name='us-east-1')

def music_exist(music_id):
    if not music_id:
        return {"error": "music_id is required"}, 500
    
    response = dynamodb.get_item(
    TableName = MUSIC_TABLE,
        Key={
            "music_id": {"S": music_id}
        }
    )

    if "Item" not in response:
        raise Exception("Music record not found", 500)
    else:
        print("Music exist in db")

def subscribe(music_id, user_email):

    dynamodb.put_item(
        TableName = SUBSCRIBE_TABLE,
        Item={
            "subscribe_id": {"S": f"{music_id}_{user_email}"},
            "music_id" : {"S": music_id},
            "user_email": {"S": user_email}
            }
    )

    print("Music is subscribed")
                
def subscribe_music(email, music_id):
    
    music_exist(music_id)
    subscribe(music_id, email)
    return "Music is subscribed"

def lambda_handler(event, context):
    
    print(event)

    try:
        token = event.get("token") 
        if not token:
            return {
                "statusCode": 401,
                "body": json.dumps({"error": "Token not provided"})
            }
        
        result = verify_token(token)
        
        print("Token", result)
        if not result["valid"]:
            return {
                "statusCode": 401,
                "body": {"error": result["error"]}
            }
        music = subscribe_music(result['user']['email'],event.get("music_id"))

        print("End of response", music)
        return {"statusCode":201, "body" : {"message":music}}

    except Exception as e:
        print(e)
        return {
            "statusCode": e.args[1] if len(e.args) > 1 else 500, 
            "body": {"error": e.args[0] if len(e.args) > 0 else 'Internal error. Try again'}
        }