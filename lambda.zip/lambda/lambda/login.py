import base64
import datetime
import json
import boto3
import re
from botocore.exceptions import ClientError

dynamodb = boto3.client('dynamodb', region_name='us-east-1')

def validate_payload(data):
    # Extract fields
    password = data.get("password")
    username = data.get("user_name")
    email = data.get("email")

    # Email validation
    email_regex = r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)"
    if not email or not re.match(email_regex, email):
        raise Exception("Invalid email address", 400)

    # Password validation
    if not password or len(password) < 8:
        raise Exception("Password must be at least 8 characters long", 400)

    return (email, username, password)

def validate_user(data):
        # Retrieve user details from DynamoDB
        response = dynamodb.get_item(
            TableName="login",
            Key={"email": {"S": data.get("email")}}
        )
            
        # If the user is not found, return an error
        if "Item" not in response:
            raise Exception("User not found", 401)
        
        user = response["Item"]
        password = user["password"]["S"] 

        # Compare the decoded password with the input password
        if password != data.get("password"):
            raise Exception("Invalid email or password", 401)
        
        return response

def generate_jwt(user):
        """Generates a JWT token with a 2-day expiry"""

        email = user["email"]["S"]
        username = user["user_name"]["S"]
       
        expiration = (datetime.datetime.utcnow() + datetime.timedelta(days=2)).isoformat()

        payload = {
            "email": email,
            "username": username,
            "exp": expiration  # Expiry time
        }

        # Generating a token
        json_payload = json.dumps(payload)
        payload_bytes = json_payload.encode('utf-8')
        base64_payload = base64.b64encode(payload_bytes).decode('utf-8')

        return {"token":base64_payload, "userName": username}
        
def lambda_handler(event, context):
    try:
        body = event

        validate_payload(body)
        response = validate_user(body)
        body = generate_jwt(response["Item"])

        return {"statusCode": 201, "body": body}
    except ClientError as e:
            error_message = e.response["Error"]["Message"]
            return {"statusCode":500,"body":{"error": f"AWS DynamoDB Error: {error_message}"}}
    except Exception as e:
        return {
            "statusCode": e.args[1] if len(e.args) > 1 else 500, 
            "body": {"error": str(e.args[0] if len(e.args) > 0 else 'Internal error. Try again')}
        }