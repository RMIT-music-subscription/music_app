import json
import boto3
from auth_utils import verify_token
 
SUBSCRIBE_TABLE = "subscribe"
MUSIC_TABLE = "music"
AWS_S3 = "music-rmit-asv33"
dynamodb = boto3.client('dynamodb', region_name='us-east-1')
 
def unsubscribe(subscription_id):
    dynamodb.delete_item(
        TableName = SUBSCRIBE_TABLE,
        Key={
            "subscribe_id": {"S": subscription_id}
        }
    )
               
def unsubscribe_music(email, music_id):
    unsubscribe(f"{music_id}_{email}")
    return "Music is unsubscribed"
 
def lambda_handler(event, context):
    
    print(event)
 
    try:
        token = event.get("token")
        if not token:
            return {
                "statusCode": 401,
                "body": json.dumps({"error": "Token not provided"})
            }
        
        result = verify_token(token)
        
        print("Token", result)
        if not result["valid"]:
            return {
                "statusCode": 401,
                "body": {"error": result["error"]}
            }
        music = unsubscribe_music(result['user']['email'],event.get("music_id"))
 
        print("End of response", music)
        return {"statusCode":201, "body" : {"message":music}}
 
    except Exception as e:
        print(e)
        return {
            "statusCode": e.args[1] if len(e.args) > 1 else 500,
            "body": {"error": e.args[0] if len(e.args) > 0 else 'Internal error. Try again'}
        }